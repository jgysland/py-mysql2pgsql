:mod:`postgres_writer`
===========================

.. automodule:: mysql2pgsql.lib.postgres_writer
   :members:
   :undoc-members:
