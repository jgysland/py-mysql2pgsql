:mod:`mysql_reader`
===================

.. automodule:: mysql2pgsql.lib.mysql_reader
   :members:
   :undoc-members:
