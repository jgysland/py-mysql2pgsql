:mod:`postgres_file_writer`
===========================

.. automodule:: mysql2pgsql.lib.postgres_file_writer
   :members:
