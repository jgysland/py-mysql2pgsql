:mod:`mysql2pgsql`
==================

.. automodule:: mysql2pgsql.mysql2pgsql
   :members:
   :undoc-members:
