API Documentation
=================

Just in case you're interested in digging into the internals

.. toctree::
   :glob:
   :maxdepth: 2

   mysql2pgsql/*
