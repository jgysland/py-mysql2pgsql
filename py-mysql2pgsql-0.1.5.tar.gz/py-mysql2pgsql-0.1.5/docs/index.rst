.. py-mysql2pgsql documentation master file, created by
   sphinx-quickstart on Tue Aug  9 12:17:31 2011.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.




.. include:: ../README.rst



Contents:

.. toctree::
   :maxdepth: 2

   api/index
   changes

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
